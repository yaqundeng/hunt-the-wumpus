/**
 * TypeOfMaze lists all the maze types
 */
public enum TypeOfMaze {
    PERFECT,
    WRAPPED,
    NONWRAPPED
}
